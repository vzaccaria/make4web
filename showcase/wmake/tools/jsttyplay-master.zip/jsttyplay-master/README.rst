JS TTY Play
===========

A javascript utility to playback files recorded using ``ttyrec``.

Disclaimer
==========

As permitted by the BSD License, this work has been retrieved from
http://encryptio.com/code/jsttyplay and replublished here.

When using these tools for the first time, I ran into some problems and fixed
them locally. As I beleive others can benefit from this as well, I decided to
re-upload them to github, which should make collaboration easier.
